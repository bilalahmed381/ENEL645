# Pothole Detection  > v1
https://universe.roboflow.com/aegis/pothole-detection-i00zy

Provided by a Roboflow user
License: CC BY 4.0

